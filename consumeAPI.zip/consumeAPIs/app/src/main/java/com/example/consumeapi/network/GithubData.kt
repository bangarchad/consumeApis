package com.example.consumeapi.network

import com.squareup.moshi.Json

data class GithubData(
    val id: String,
    val email: String,
    val first_name: String,
    val avatar: String
)